const express = require("express");

const app = express();

// Constants
const PORT = 8080;
const HOST = '0.0.0.0';

app.get("/", function (req, res) {
    res.send("¡Primer lab completado! ¡Logramos desplegar una aplicación en un contenedor!");
})

app.listen(PORT, HOST, () => {
    console.log(`App listening on port ${PORT}`);
})